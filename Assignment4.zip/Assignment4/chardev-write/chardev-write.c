#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <asm/uaccess.h>
#include <linux/mutex.h>

// #include "../chardev.h"

extern int init_module(void);
extern void cleanup_module(void);
static int device_open(struct inode *, struct file* );
static int device_release(struct inode *, struct file* );
static ssize_t device_write(struct file *, const char* , size_t, loff_t *);

#define SUCCESS 0
#define DEVICE_NAME "chardev-write"
#define BUFFER_SIZE 1024

static int majorNumber;
static int deviceOpen = 0;

// fucky stuff
char queue[BUFFER_SIZE];
int head = 0;
int queueLen = 0;
struct mutex queue_mutex;

const char *ucf_string = "Undefeated 2018 National Champions UCF";
const int ucf_length = 38;
int num_chars_checked = 0;

EXPORT_SYMBOL(queue);
EXPORT_SYMBOL(head);
EXPORT_SYMBOL(queueLen);
EXPORT_SYMBOL(queue_mutex);
EXPORT_SYMBOL(num_chars_checked);
// end of fucky stuff


static struct file_operations fops = {
    .write = device_write,
    .open = device_open,
    .release = device_release,
};

extern int init_module(void) {
    printk(KERN_INFO "Installing module.\n");

    majorNumber = register_chrdev(0, DEVICE_NAME, &fops);

    if (majorNumber < 0) {
        printk(KERN_ALERT "Device registration failed: %d\n", majorNumber);
        return majorNumber;
    }
    printk(KERN_INFO "I was assigned major number %d. To talk to\n", majorNumber);
    printk(KERN_INFO "the driver, create a dev file with\n");
    printk(KERN_INFO "'mknod /dev/%s c %d 0'.\n", DEVICE_NAME, majorNumber);
    printk(KERN_INFO "Try to cat and echo to the device file.\n");
    printk(KERN_INFO "Remove the device file and module when done.\n");

    // init mutex
    mutex_init(&queue_mutex);

    return SUCCESS;
}

extern void cleanup_module(void) {
    printk(KERN_INFO "Removing module.\n");
     unregister_chrdev(majorNumber, DEVICE_NAME);
}

static int device_open(struct inode *inode, struct file *file){
    if (deviceOpen){
        return -EBUSY;
    }

    deviceOpen++;
    try_module_get(THIS_MODULE);

    printk(KERN_INFO "Device Opened.\n");
    return 0;
}
static int device_release(struct inode *inode, struct file *file){
    deviceOpen--;
    module_put(THIS_MODULE);

    printk(KERN_INFO "Device Released.\n");

    return 0;
}

static void replaceUCF(void)
{
    int j, k;
    int index_U, index_C, index_F;
    int index;
    int first_loop;
    
    // printk(KERN_INFO "replaceUCF Qlen is: %d\n", queueLen);
    // printk(KERN_INFO "Qlen-num_chars_checked is: %d\n", (queueLen - num_chars_checked));

    while(num_chars_checked < queueLen - 2)
    {
        index_U = (head + num_chars_checked) % BUFFER_SIZE;
        index_C = (index_U + 1) % BUFFER_SIZE;
        index_F = (index_C + 1) % BUFFER_SIZE;

        if(index_C == head || index_F == head) {
            break;
        }

        if(queue[index_U] == 'U' && queue[index_C] == 'C' && queue[index_F] == 'F') {
            //printk(KERN_INFO "\n\nFound UCF\n\n");

            if(BUFFER_SIZE - queueLen >= ucf_length - 3) {
                //printk(KERN_INFO "Chars checked before: %d, next 3: %c %c %c\n", num_chars_checked, queue[num_chars_checked], queue[(num_chars_checked+1)%BUFFER_SIZE], queue[(num_chars_checked+2)%BUFFER_SIZE]);

                if((BUFFER_SIZE - queueLen) < ucf_length) {
                    queueLen = BUFFER_SIZE;
                    num_chars_checked = queueLen - 2;
                }
                else {
                    queueLen += ucf_length - 3;
                    num_chars_checked += ucf_length - 2;
                }

                // start at last index
                // try to move each character forward by ucf_length
                // stop when we get to index_U + ucf_length
                for(k=(head + BUFFER_SIZE + queueLen - 1) % BUFFER_SIZE; k != (index_U + BUFFER_SIZE + ucf_length - 1) % BUFFER_SIZE; k = (k + BUFFER_SIZE - 1) % BUFFER_SIZE) {
                    queue[k] = queue[(k + BUFFER_SIZE - (ucf_length - 3)) % BUFFER_SIZE];
                }
            }

            index = index_U;
            j = 0;
            first_loop = 1;

            while((first_loop || index != head) && j < ucf_length)
            {
                first_loop = 0;
                queue[index] = ucf_string[j];
                index = (index + 1) % BUFFER_SIZE;
                j++;
            }

            //printk(KERN_INFO "Chars checked after: %d, next 3: %c %c %c\n", num_chars_checked, queue[num_chars_checked], queue[(num_chars_checked+1)%BUFFER_SIZE], queue[(num_chars_checked+2)%BUFFER_SIZE]);
        }
        else {
            num_chars_checked++;
        }
    }
}

static ssize_t device_write(struct file *file, const char *buffer, size_t length, loff_t *offset)
{
    int buffer_space;
    int i;

    mutex_lock(&queue_mutex);

    buffer_space = BUFFER_SIZE - queueLen;

    if (buffer_space <= 0) {
        mutex_unlock(&queue_mutex);
    	return length;
    }

    if(length > buffer_space) {
        length = buffer_space;
    }

    for(i=0; i<length; i++) {
        queue[(head + queueLen + i) % BUFFER_SIZE] = buffer[i];
    }

    queueLen += length;
    //printk(KERN_INFO "device_write Qlen is: %d\n", queueLen);

    replaceUCF();

    mutex_unlock(&queue_mutex);

    printk(KERN_INFO "Device Write: received %zu characters\n", length);
    return length;
}